
export interface Machine {
  id: string;
  name: string;
  brand: 'Canon' | 'Konica' | 'Kyocera' | 'HP' | 'Xerox';
  type: 'Color' | 'B&W';
  category: 'Desktop' | 'Office' | 'Production' | 'Industrial';
  image: string;
  description: string;
  price: number;
  rentalPrice: number;
  features: string[];
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  avatar: string;
}
