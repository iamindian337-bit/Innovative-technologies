import React from 'react';
import { Machine, Testimonial } from './types';

export const Logo = () => (
  <div className="flex items-center gap-3">
    <div className="relative w-10 h-10 flex items-center justify-center">
      <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 gap-[2px] opacity-40">
        {[...Array(9)].map((_, i) => (
          <div key={i} className="bg-red-500/40 rounded-sm"></div>
        ))}
      </div>
      <div className="relative z-10 flex flex-col items-center">
        <div className="w-2.5 h-2.5 bg-red-600 mb-1 rounded-sm shadow-[0_0_10px_rgba(220,38,38,0.5)]"></div>
        <div className="w-2.5 h-5 bg-red-600 rounded-sm shadow-[0_0_15px_rgba(220,38,38,0.3)]"></div>
      </div>
    </div>
    <div className="flex flex-col leading-none">
      <span className="text-xl font-black tracking-tighter text-white uppercase group-hover:text-red-500 transition-colors">Innovative</span>
      <span className="text-lg font-medium tracking-wide text-zinc-400 uppercase">Technologies</span>
      <div className="h-[1px] w-full bg-red-600/30 my-2"></div>
      <span className="text-[9px] tracking-[0.3em] text-red-500 uppercase font-black">Copy & Print Experts</span>
    </div>
  </div>
);

export const MACHINES_DATA: Machine[] = [
  // CANON COLOUR
  { id: 'can-c1', name: 'Canon IR Advance C3326', brand: 'Canon', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/4/413932909/EM/JQ/YD/217716529/canon-color-photocopy-machine-c3326i-1000x1000.jpg', description: 'Advanced color performance for modern business.', price: 0, rentalPrice: 0, features: ['Vivid Color', 'User Friendly', 'Secure'] },
  { id: 'can-c2', name: 'Canon IR Advance C5530', brand: 'Canon', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2025/12/564789681/TR/YM/ON/101252437/canon-ir-advance-4545i-digital-photocopier-machine-for-commercial-purpose-only-1000x1000.png', description: 'High-speed color engine for high-demand clusters.', price: 0, rentalPrice: 0, features: ['Vivid Color', 'Fast Scan', 'Cloud Ready'] },
  { id: 'can-c3', name: 'Canon IR Advance C5560', brand: 'Canon', type: 'Color', category: 'Production', image: 'https://copiersonsale.com/wp-content/uploads/2025/04/Canon-imageRUNNER-ADVANCE-C5560i-Low-Price.jpg', description: 'Enterprise solution for heavy color workflows.', price: 0, rentalPrice: 0, features: ['60 PPM Color', 'Large Capacity', 'Professional Finishing'] },

  // CANON B&W
  { id: 'can-b1', name: 'Canon IR Advance 4535', brand: 'Canon', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/ANDROID/Default/2024/10/458489482/LT/GQ/JG/69538245/product-jpeg-500x500.jpg', description: 'Reliable monochrome performance.', price: 0, rentalPrice: 0, features: ['35 PPM B&W', 'Touch Display', 'Eco-friendly'] },
  { id: 'can-b2', name: 'Canon IR Advance 4545', brand: 'Canon', type: 'B&W', category: 'Office', image: 'https://www.copierschicago.com/sites/default/files/imagecache/product_big/canon-copiers/canon-ira-c2225-copier.jpg', description: 'Efficient document management.', price: 0, rentalPrice: 0, features: ['45 PPM B&W', 'Compact Design', 'Smart Tech'] },
  { id: 'can-b3', name: 'Canon IR Advance 4555', brand: 'Canon', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/HQ/IB/MY-8246744/canon-imagerunner-advance-copier-1000x1000.jpg', description: 'Heavy-duty monochrome workhorse.', price: 0, rentalPrice: 0, features: ['55 PPM B&W', 'Rapid Output', 'Durable'] },
  { id: 'can-b4', name: 'Canon IR Advance 4735', brand: 'Canon', type: 'B&W', category: 'Office', image: 'https://in.canon/media/image/2025/06/25/da6f826bfa044227bbef589e1ddc08fb_imageFORCE+Multi-function+Device+S_ASIA+03.png', description: 'Next-gen document handling.', price: 0, rentalPrice: 0, features: ['Smart Scanning', 'Modern UI', 'Secure'] },
  { id: 'can-b5', name: 'Canon IR Advance 4745', brand: 'Canon', type: 'B&W', category: 'Office', image: 'https://cpimg.tistatic.com/11057651/b/4/Canon-ir-4745-Photocopier-Machine..jpg', description: 'Professional monochrome solution.', price: 0, rentalPrice: 0, features: ['High Efficiency', 'Large Screen', 'Energy Saving'] },
  { id: 'can-b6', name: 'Canon IR Advance 4755', brand: 'Canon', type: 'B&W', category: 'Office', image: 'https://www.printersoffice.com/archivio/fotografie/98684.jpg?49903', description: 'Superior text clarity and speed.', price: 0, rentalPrice: 0, features: ['55 PPM', 'Precision Print', 'Robust'] },
  { id: 'can-b7', name: 'Canon IR Advance 6565', brand: 'Canon', type: 'B&W', category: 'Industrial', image: 'https://5.imimg.com/data5/SELLER/Default/2022/11/BD/XV/AN/2080525/image-runner-advance-6555i-1000x1000.jpg', description: 'Massive volume production machine.', price: 0, rentalPrice: 0, features: ['65 PPM Industrial', 'Heavy Duty', 'Stacker Ready'] },
  { id: 'can-b8', name: 'Canon IR Advance 6575', brand: 'Canon', type: 'B&W', category: 'Industrial', image: 'https://5.imimg.com/data5/SH/HS/GLADMIN-10615997/image-runner-advance-6575i-1000x1000.png', description: 'Extreme reliability for copy centers.', price: 0, rentalPrice: 0, features: ['75 PPM', 'High Capacity Tray', 'Fast DADF'] },
  { id: 'can-b9', name: 'Canon IR Advance 6780', brand: 'Canon', type: 'B&W', category: 'Industrial', image: 'https://5.imimg.com/data5/HJ/MU/KA/SELLER-41183083/canon-ir-adv-6575i-75-ppm-digital-multifunction-photocopy-machine-with-copy-tray-image-reader-pcl-1000x1000.jpg', description: 'Top-tier digital multifunction.', price: 0, rentalPrice: 0, features: ['Digital Master', 'Network Ready', 'Advanced Security'] },
  { id: 'can-b10', name: 'Canon IR Advance 8505', brand: 'Canon', type: 'B&W', category: 'Industrial', image: 'https://5.imimg.com/data5/PZ/JX/SH/GLADMIN-64542293/selection-084-1000x1000.png', description: 'Ultra-high speed 105 PPM production.', price: 0, rentalPrice: 0, features: ['105 PPM', 'Massive Tray', 'Industrial Grade'] },

  // KONICA MINOLTA
  { id: 'kon-b1', name: 'Konica Bizhub 367', brand: 'Konica', type: 'B&W', category: 'Office', image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcRzyKYq8tz6VQC-tnUVsd7euSfVg-JLR5N3MndVy2Vqo9xRp8klAgEQd-vVfO7SsoOYQn_cQJ04wHQRJ7LjTKWyGt5v3kwTog', description: 'Smart B&W workflow.', price: 0, rentalPrice: 0, features: ['Mobile Print', '36 PPM', 'Touch UI'] },
  { id: 'kon-b2', name: 'Konica Bizhub 287', brand: 'Konica', type: 'B&W', category: 'Office', image: 'https://konicaminolta.b-cdn.net/wp-content/uploads/2022/03/Konica_Minolta_bizhub_287_Multifunction_Printer-1.png', description: 'Compact office solution.', price: 0, rentalPrice: 0, features: ['Eco Design', 'User Auth', 'Reliable'] },
  { id: 'kon-b3', name: 'Konica Bizhub 308', brand: 'Konica', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/VY/DD/DP/SELLER-2063450/konica-minolta-printing-machine-1000x1000.JPG', description: 'High-end B&W output.', price: 0, rentalPrice: 0, features: ['High Clarity', 'Fast Warmup', 'Secure'] },
  { id: 'kon-b4', name: 'Konica Bizhub 45', brand: 'Konica', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2021/6/YX/JJ/UF/12724505/227-1-1000x1000.png', description: 'Workgroup efficiency.', price: 0, rentalPrice: 0, features: ['Consistent', 'Easy Setup', 'Networkable'] },
  { id: 'kon-b5', name: 'Konica Bizhub 558', brand: 'Konica', type: 'B&W', category: 'Production', image: 'https://5.imimg.com/data5/SELLER/Default/2021/9/UX/FO/VP/119097728/konica-minolta-458e-multifunction-printer-1000x1000.jpg', description: 'Speed for big jobs.', price: 0, rentalPrice: 0, features: ['55 PPM', 'High Capacity', 'Advanced Finishing'] },
  { id: 'kon-c1', name: 'Konica C458', brand: 'Konica', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/10/461553179/KP/VF/MO/9381425/bizhub-c458-konica-minolta-photocopy-machine-1000x1000.jpeg', description: 'Pro-grade color.', price: 0, rentalPrice: 0, features: ['Superior Color', 'Fast Scan', 'Smart UI'] },
  { id: 'kon-c2', name: 'Konica C558', brand: 'Konica', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2023/10/351615961/KY/IH/UC/48677337/konica-c458-photocopy-machine-1000x1000.png', description: 'Robust color engine.', price: 0, rentalPrice: 0, features: ['55 PPM Color', 'SSD Storage', 'Vivid output'] },
  { id: 'kon-c3', name: 'Konica C250i', brand: 'Konica', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2022/5/EB/ZY/BD/99018994/konica-minolta-bizhub-c250i-multifunctional-office-printer-1000x1000.png', description: 'Modern i-Series color.', price: 0, rentalPrice: 0, features: ['AI Integrated', 'Simple UI', 'Bitdefender Secure'] },
  { id: 'kon-c4', name: 'Konica C450i', brand: 'Konica', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/4/412517344/UN/XF/AW/5567825/konica-minolta-bizhub-c650i-1000x1000.png', description: 'High-speed i-Series.', price: 0, rentalPrice: 0, features: ['Next-gen speed', 'Eco-friendly', 'App Support'] },

  // KYOCERA
  { id: 'kyo-b1', name: 'Kyocera MA 4000x', brand: 'Kyocera', type: 'B&W', category: 'Desktop', image: 'https://cdn.moglix.com/p/Xgwt3GqVgQJFC-xxlarge.jpg', description: 'Legendary reliability.', price: 0, rentalPrice: 0, features: ['EcoSys', 'Low Operating Cost', 'Tough'] },
  { id: 'kyo-b2', name: 'Kyocera MA 4500x', brand: 'Kyocera', type: 'B&W', category: 'Desktop', image: 'https://www.kyoceradocumentsolutions.eu/en/products/mfp/ECOSYSMA4500X/_jcr_content/root/container/container_card/carousel_copy_copy_copy/teaser_3.coreimg.png/1672660752773/square-540x540-ecosys-pa4500x.png', description: 'Efficient desktop performance.', price: 0, rentalPrice: 0, features: ['Fast Print', 'Network Ready', 'Compact'] },
  { id: 'kyo-b3', name: 'Kyocera M2 3200', brand: 'Kyocera', type: 'B&W', category: 'Office', image: 'https://businessmachines.co.ke/wp-content/uploads/2025/03/kyocera-taskalfa-4002i.jpg', description: 'Reliable office assistant.', price: 0, rentalPrice: 0, features: ['Taskalfa Engine', 'Long Life', 'Clear B&W'] },
  { id: 'kyo-c1', name: 'Kyocera TASKalfa 3212i', brand: 'Kyocera', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/5/418749306/FK/HC/NE/23687561/kyocera-ta-mz3200i-1000x1000.webp', description: 'Professional color series.', price: 0, rentalPrice: 0, features: ['HyPAS', 'Vivid Color', 'Modular'] },
  { id: 'kyo-c2', name: 'Kyocera TASKalfa 4012i', brand: 'Kyocera', type: 'Color', category: 'Office', image: 'https://kentique.co.ke/wp-content/uploads/2021/03/Kyocera-TASKalfa-4012i-A3-Laser-printer.jpg', description: 'High-performance TASKalfa.', price: 0, rentalPrice: 0, features: ['40 PPM', 'Industrial Quality', 'Advanced Apps'] },

  // HP
  { id: 'hp-1', name: 'HP M72525', brand: 'HP', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/UN/VB/MY-2446774/hp-laserjet-m72525-mfp-1000x1000.jpg', description: 'Managed HP reliability.', price: 0, rentalPrice: 0, features: ['Secure', 'Managed Spares', 'JetIntelligence'] },
  { id: 'hp-2', name: 'HP 72630', brand: 'HP', type: 'B&W', category: 'Office', image: 'https://in-media.apjonlinecdn.com/catalog/product/cache/b3b166914d87ce343d4dc5ec5117b502/2/Z/2ZN50A-1_T1680401321.png', description: 'Advanced HP LaserJet.', price: 0, rentalPrice: 0, features: ['Modern UI', 'HP Wolf Security', 'Fast Scan'] },

  // XEROX COLOUR
  { id: 'xer-c1', name: 'Xerox Versant 80', brand: 'Xerox', type: 'Color', category: 'Production', image: 'https://cpimg.tistatic.com/04670469/b/5/Xerox-Versant-80-Digital-Colour-Press.jpg', description: 'Production press quality.', price: 0, rentalPrice: 0, features: ['Ultra HD', 'Pro Finishing', '80 PPM'] },
  { id: 'xer-c2', name: 'Xerox Versant 180', brand: 'Xerox', type: 'Color', category: 'Production', image: 'https://images-cdn.ubuy.co.id/654867460a03bb461c20a7c5-used-xerox-versant-180-press-digital.jpg', description: 'Next-gen production.', price: 0, rentalPrice: 0, features: ['Superior Color', 'Vast Media Support', 'Heavy Duty'] },
  { id: 'xer-c3', name: 'Xerox C60', brand: 'Xerox', type: 'Color', category: 'Production', image: 'https://img2.exportersindia.com/product_images/bc-full/2020/5/6473285/xerox-color-c-60-production-printer-1589517692-5431776.jpeg', description: 'Production color master.', price: 0, rentalPrice: 0, features: ['Versatile', 'Professional Grade', 'Stable'] },
  { id: 'xer-c4', name: 'Xerox C70', brand: 'Xerox', type: 'Color', category: 'Production', image: 'https://5.imimg.com/data5/GW/LF/YR/GLADMIN-12/c60-500x500.png', description: 'High-fidelity printing.', price: 0, rentalPrice: 0, features: ['Clear Text', 'Rich Images', 'Networked'] },
  { id: 'xer-c5', name: 'Xerox AltaLink C8130', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2020/10/ZP/UC/IJ/9062248/xerox-altalink-c8030-1000x1000.png', description: 'Smart workplace assistant.', price: 0, rentalPrice: 0, features: ['ConnectKey', 'Tablet UI', 'McAfee Secure'] },
  { id: 'xer-c6', name: 'Xerox C8145', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/6/425838438/DK/UC/VU/6414009/xerox-altalink-c8145-printer-1000x1000.jpg', description: 'Faster office color.', price: 0, rentalPrice: 0, features: ['45 PPM Color', 'Custom Apps', 'Robust'] },
  { id: 'xer-c7', name: 'Xerox C8155', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://static1.industrybuying.com/products/it-electronics/printers/multifunction-printers/ITE.MUL.47774941_1673015568237.webp', description: 'Top office color speed.', price: 0, rentalPrice: 0, features: ['55 PPM', 'Large Capacity', 'Precision'] },
  { id: 'xer-c8', name: 'Xerox AltaLink C8030', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/YA/SN/XN/SELLER-47121970/xerox-altalink-c8030-color-multifunction-printer.jpg', description: 'Reliable office assistant.', price: 0, rentalPrice: 0, features: ['ConnectKey', 'User Friendly', 'Secure'] },
  { id: 'xer-c9', name: 'Xerox C8045', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://copiersonsale.com/wp-content/uploads/2025/04/Xerox-AltaLink-C8045-1.jpg', description: 'Balanced color performance.', price: 0, rentalPrice: 0, features: ['45 PPM', 'Multi-touch UI', 'Cloud Gallery'] },
  { id: 'xer-c10', name: 'Xerox C8055', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2021/2/DO/QV/HM/3885680/xerox-altalink-c8055-colour-multifunction-printer-copier-scanner-a3-size.jpg', description: 'Powerful office cluster engine.', price: 0, rentalPrice: 0, features: ['High Speed', 'Pro Scan', 'Secure Print'] },
  { id: 'xer-c11', name: 'Xerox VersaLink C7125', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3r1qM6Od_rdr3YSoW-pJf4b6Rck7aWlTJkg&s', description: 'Modern color compact.', price: 0, rentalPrice: 0, features: ['Mobile Ready', 'Cloud Link', 'Solid'] },
  { id: 'xer-c12', name: 'Xerox C7130', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2023/9/341532283/KS/AY/MY/3106008/c7130-10-500x500.jpg', description: 'Efficient color workgroup.', price: 0, rentalPrice: 0, features: ['30 PPM Color', 'Versatile', 'Tablet-like'] },
  { id: 'xer-c13', name: 'Xerox C7135', brand: 'Xerox', type: 'Color', category: 'Office', image: 'https://www.cortronsystems.com/wp-content/uploads/2019/04/C7035_OTHER10_1512x1296.jpg', description: 'High-spec VersaLink.', price: 0, rentalPrice: 0, features: ['35 PPM', 'High Res', 'Easy Service'] },

  // XEROX B&W
  { id: 'xer-b1', name: 'Xerox AltaLink B8130', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://www.absolutetoner.com/cdn/shop/products/XeroxAltaLinkC8130H2_720x.jpg?v=1662873836', description: 'Superior B&W workflow.', price: 0, rentalPrice: 0, features: ['Secure', 'ConnectKey', 'Fast Scan'] },
  { id: 'xer-b2', name: 'Xerox B8135', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://static1.industrybuying.com/products/it-electronics/printers/multifunction-printers/ITE.MUL.37774926_1673015548671.webp', description: 'Reliable office mono.', price: 0, rentalPrice: 0, features: ['35 PPM B&W', 'Touch Screen', 'Robust'] },
  { id: 'xer-b3', name: 'Xerox B8145', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2022/11/RL/MH/XW/1971692/xerox-mono-multifunctional-printer-altalink-b8145-1000x1000.jpg', description: 'High speed monochrome.', price: 0, rentalPrice: 0, features: ['45 PPM B&W', 'McAfee Integrated', 'Flexible'] },
  { id: 'xer-b4', name: 'Xerox B8155', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/2/393552765/IC/OL/MF/2146711/xerox-altalink-b8155-1000x1000.jpg', description: 'Enterprise B&W assistant.', price: 0, rentalPrice: 0, features: ['55 PPM', 'High Tray Capacity', 'Secure'] },
  { id: 'xer-b5', name: 'Xerox B8170', brand: 'Xerox', type: 'B&W', category: 'Industrial', image: 'https://5.imimg.com/data5/SELLER/Default/2024/6/426713632/QN/QX/FA/6414009/xerox-altalink-b8170-multifunction-printer-1000x1000.jpg', description: 'Industrial monochrome beast.', price: 0, rentalPrice: 0, features: ['72 PPM', 'Heavy Duty', 'Massive Output'] },
  { id: 'xer-b6', name: 'Xerox AltaLink B8230', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://www.cortronsystems.com/wp-content/uploads/2019/04/C8030_OTHER9_888x1120.jpg', description: 'Modern mono workplace.', price: 0, rentalPrice: 0, features: ['ConnectKey Ready', 'Fast', 'Precise'] },
  { id: 'xer-b7', name: 'Xerox B8235', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://copiersonsale.com/wp-content/uploads/2025/04/Xerox-AltaLink-B8075-Refurbished-600x451.jpg', description: 'Balanced B&W engine.', price: 0, rentalPrice: 0, features: ['35 PPM', 'Stable', 'Networked'] },
  { id: 'xer-b8', name: 'Xerox B8245', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://www.shop.xerox.com/media/catalog/product/cache/d71c9e55e6299aa8261d6db30899d521/b/8/b8145-1000x1000_1.jpg', description: 'Workgroup monochrome.', price: 0, rentalPrice: 0, features: ['45 PPM', 'Efficient', 'Proven'] },
  { id: 'xer-b9', name: 'Xerox B8255', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2025/3/497888078/FQ/PP/XV/71049097/xerox-altalink-b8255-multifunction-printer-1000x1000.jpg', description: 'High-output workgroup.', price: 0, rentalPrice: 0, features: ['55 PPM', 'Smart Apps', 'Fast'] },
  { id: 'xer-b10', name: 'Xerox B8270', brand: 'Xerox', type: 'B&W', category: 'Industrial', image: 'https://5.imimg.com/data5/SELLER/Default/2025/6/519783940/OK/ZH/KT/3846491/compressjpeg-online-img-1000x1000.jpg', description: 'Powerhouse monochrome.', price: 0, rentalPrice: 0, features: ['70 PPM', 'Massive Durability', 'Expert Scan'] },
  { id: 'xer-b11', name: 'Xerox AltaLink B8055', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/10/455078613/IZ/NI/EI/3555387/xerox-altalink-b8055-multifunction-printer-1000x1000.png', description: 'Reliable office assistant.', price: 0, rentalPrice: 0, features: ['Proven Tech', 'Secure', 'Clear Text'] },
  { id: 'xer-b12', name: 'Xerox AltaLink B8155', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2023/12/369228227/KW/NL/XE/28200628/xerox-altalink-b8155-1000x1000.jpg', description: 'Enterprise grade B&W.', price: 0, rentalPrice: 0, features: ['McAfee Integrated', '55 PPM', 'Vivid B&W'] },
  { id: 'xer-b13', name: 'Xerox VersaLink B7125', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://printerpoint.co.in/wp-content/uploads/2024/07/Xerox-VersaLink-B7125-Wired-Laser-Multifunction-Printer-768x384.jpg', description: 'Compact VersaLink B&W.', price: 0, rentalPrice: 0, features: ['Tablet UI', 'Cloud Gallery', 'Easy'] },
  { id: 'xer-b14', name: 'Xerox VersaLink B7130', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2025/6/519758211/PZ/DO/NA/3846491/compressjpeg-online-img-1-1000x1000.jpg', description: '30 PPM VersaLink.', price: 0, rentalPrice: 0, features: ['Networked', 'App Ready', 'Modern'] },
  { id: 'xer-b15', name: 'Xerox VersaLink B7135', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://cdn.moglix.com/p/nshaFfUCsuI5S-xxlarge.jpg', description: '35 PPM VersaLink.', price: 0, rentalPrice: 0, features: ['Fast', 'User Authentication', 'Secure'] },
  { id: 'xer-b16', name: 'Xerox WorkCentre 5945', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2024/10/459008490/NV/TA/BS/223801653/xerox-workcentre-5945-1000x1000.jpg', description: 'The 45 PPM classic.', price: 0, rentalPrice: 0, features: ['Stable', 'Great Imaging', 'Reliable'] },
  { id: 'xer-b17', name: 'Xerox WorkCentre 5955', brand: 'Xerox', type: 'B&W', category: 'Office', image: 'https://5.imimg.com/data5/SELLER/Default/2023/9/348171084/AP/IL/JX/22661714/xerox-workcentre-5955-multifunction-printer-1000x1000.png', description: 'The 55 PPM workhorse.', price: 0, rentalPrice: 0, features: ['Production Ready', 'Clean output', 'Solid'] }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "John Sharma",
    role: "Proprietor, Minerva Hub",
    content: "We've used Innovative Technologies for years. Their Xerox and Canon machines are the backbone of our business.",
    avatar: "https://i.pravatar.cc/150?u=print1"
  },
  {
    id: 2,
    name: "Priya Rao",
    role: "Facility Manager, SD Road",
    content: "Excellent maintenance services. The Kyocera machines they provided have the lowest running costs we've seen.",
    avatar: "https://i.pravatar.cc/150?u=print2"
  }
];