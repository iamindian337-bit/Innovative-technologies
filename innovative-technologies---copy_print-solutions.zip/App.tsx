
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useSpring } from 'framer-motion';
import { 
  ArrowRight, 
  ShoppingCart, 
  Calendar, 
  CheckCircle2, 
  ShieldCheck, 
  Zap, 
  Cpu, 
  Mail, 
  Phone, 
  MapPin, 
  X,
  Droplets,
  Wrench,
  Building2
} from 'lucide-react';
import { Logo, MACHINES_DATA } from './constants';
import { Machine } from './types';
import { getMachineRecommendation } from './geminiService';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Machines', href: '#machines' },
    { name: 'Services', href: '#services' },
    { name: 'Rentals', href: '#rentals' },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-zinc-950/95 backdrop-blur-xl py-3 border-b border-red-900/20 shadow-2xl shadow-red-950/10' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex items-center justify-between">
        <a href="#home" className="no-underline active:opacity-80 transition-opacity">
          <Logo />
        </a>
        <div className="hidden md:flex items-center gap-10 font-bold uppercase text-[11px] tracking-widest">
          {navItems.map((item) => (
            <a 
              key={item.name} 
              href={item.href} 
              className="text-zinc-400 hover:text-red-500 transition-all relative group no-underline"
              onClick={(e) => {
                e.preventDefault();
                const element = document.querySelector(item.href);
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              {item.name}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-red-600 transition-all group-hover:w-full"></span>
            </a>
          ))}
          <a 
            href="#contact" 
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-2.5 rounded-lg transition-all shadow-lg shadow-red-950/30 active:scale-95 no-underline"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
          >
            Get Quote
          </a>
        </div>
      </div>
    </nav>
  );
};

const SectionHeading = ({ title, subtitle, centered = false }: { title: string; subtitle: string; centered?: boolean }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className={`mb-16 ${centered ? 'text-center' : ''}`}
  >
    <div className={`flex items-center gap-3 mb-4 ${centered ? 'justify-center' : ''}`}>
      <div className="h-[2px] w-8 bg-red-600"></div>
      <h3 className="text-red-500 font-black uppercase tracking-[0.4em] text-[10px]">{subtitle}</h3>
      <div className="h-[2px] w-8 bg-red-600"></div>
    </div>
    <h2 className="text-4xl md:text-6xl font-black tracking-tighter text-white leading-none uppercase">{title}</h2>
  </motion.div>
);

const App: React.FC = () => {
  const [activeBrand, setActiveBrand] = useState<string>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [aiInput, setAiInput] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  const filteredMachines = activeBrand === 'All' 
    ? MACHINES_DATA 
    : MACHINES_DATA.filter(m => m.brand === activeBrand);

  const handleAiConsultation = async () => {
    if (!aiInput.trim()) return;
    setIsAiLoading(true);
    const res = await getMachineRecommendation(aiInput);
    setAiResponse(res || 'Consultation unavailable.');
    setIsAiLoading(false);
  };

  const smoothScroll = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="bg-zinc-950 min-h-screen text-zinc-100 selection:bg-red-600/30 selection:text-white overflow-x-hidden">
      <motion.div className="fixed top-0 left-0 right-0 h-1 bg-red-600 origin-left z-[100]" style={{ scaleX }} />
      <Navbar />

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center pt-24">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-1/4 -left-20 w-[500px] h-[500px] bg-red-600/5 rounded-full blur-[120px]"></div>
          <div className="absolute bottom-1/4 -right-20 w-[600px] h-[600px] bg-red-900/5 rounded-full blur-[150px]"></div>
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03]"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* User requested removal of the Direct Dealers badge from here */}
            <h1 className="text-6xl md:text-8xl font-black leading-[0.85] text-white mb-8 uppercase tracking-tighter">
              BEYOND <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-red-500 to-zinc-600">ORDINARY</span> SOLUTIONS
            </h1>
            <p className="text-lg text-zinc-400 max-w-xl mb-10 leading-relaxed font-medium">
              We deal with Major brands: <span className="text-white">XEROX, CANON, HP, & KYOCERA</span>. Expert sales, services, and rentals for all types of office automation. Featuring superior <span className="text-red-500">MARKGOLD</span> quality toners.
            </p>
            <div className="flex flex-wrap gap-5">
              <a 
                href="#machines" 
                onClick={smoothScroll('#machines')}
                className="bg-red-600 hover:bg-red-700 text-white px-10 py-5 rounded-2xl font-black flex items-center gap-3 transition-all shadow-2xl shadow-red-900/40 no-underline group active:scale-95"
              >
                BROWSE FLEET <ArrowRight className="group-hover:translate-x-2 transition-transform" />
              </a>
              <a 
                href="#contact" 
                onClick={smoothScroll('#contact')}
                className="bg-zinc-900 hover:bg-zinc-800 text-white px-10 py-5 rounded-2xl font-black border border-zinc-800 flex items-center gap-3 transition-all no-underline active:scale-95"
              >
                CONTACT SALES <Phone size={20} className="text-red-500" />
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative hidden lg:block"
          >
            <div className="relative z-10 p-2 rounded-[3.5rem] bg-gradient-to-br from-red-900/20 to-transparent border border-red-900/30 overflow-hidden shadow-2xl shadow-red-950/40">
              <img 
                src="https://images.unsplash.com/photo-1594911772125-07fc7a2d8d9f?auto=format&fit=crop&q=80&w=1200" 
                alt="Production Machine" 
                className="w-full h-auto object-cover rounded-[3rem] grayscale-[0.2] contrast-125"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-transparent to-transparent"></div>
              <div className="absolute bottom-10 left-10 right-10">
                 <div className="bg-zinc-900/80 backdrop-blur-xl p-6 rounded-3xl border border-white/5 flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center shrink-0">
                      <Droplets className="text-white" size={24} />
                    </div>
                    <div>
                      <h4 className="font-black text-white text-xs uppercase tracking-widest">Markgold Toner</h4>
                      <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-tight">Imported Superior Quality</p>
                    </div>
                 </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-zinc-950">
        <div className="container mx-auto px-6">
          <SectionHeading title="Our Services" subtitle="Expert Support" />
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: <ShoppingCart />, title: "SALES", desc: "Premier range of B&W and Colour MFPs from industry leading brands like Xerox and Canon." },
              { icon: <Calendar />, title: "RENTALS", desc: "Cost-effective, hassle-free rental plans tailored for modern corporate office workflows." },
              { icon: <Wrench />, title: "SERVICES", desc: "Dedicated expert support and maintenance for all types of office automation products." }
            ].map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-zinc-900/40 p-12 rounded-[2.5rem] border border-zinc-800 hover:border-red-600/40 transition-all group relative overflow-hidden"
              >
                <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-red-600 group-hover:text-white transition-all text-red-500 shadow-xl group-hover:shadow-red-950/40">
                  {s.icon}
                </div>
                <h4 className="text-2xl font-black mb-4 uppercase tracking-tighter text-white">{s.title}</h4>
                <p className="text-zinc-500 text-sm leading-relaxed font-medium">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Inventory Section - Complete List */}
      <section id="machines" className="py-24 bg-zinc-950 relative">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-20 gap-10">
            <SectionHeading title="Full Inventory" subtitle="The Machines" />
            <div className="flex flex-wrap gap-2 p-1 bg-zinc-900 rounded-2xl border border-zinc-800">
              {['All', 'Canon', 'Konica', 'Kyocera', 'HP', 'Xerox'].map(brand => (
                <button 
                  key={brand}
                  onClick={() => setActiveBrand(brand)}
                  className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeBrand === brand ? 'bg-red-600 text-white shadow-lg' : 'text-zinc-500 hover:text-white'}`}
                >
                  {brand}
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
            <AnimatePresence mode="popLayout">
              {filteredMachines.map((m) => (
                <motion.div
                  layout
                  key={m.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="group bg-zinc-900/60 rounded-[3rem] border border-zinc-800/50 overflow-hidden flex flex-col hover:border-red-600/30 transition-all hover:shadow-2xl hover:shadow-red-950/20"
                >
                  {/* Container for image to handle white backgrounds gracefully */}
                  <div className="relative h-72 bg-white m-3 rounded-[2.5rem] flex items-center justify-center p-8 overflow-hidden">
                    <img src={m.image} alt={m.name} className="max-w-full max-h-full object-contain group-hover:scale-110 transition-transform duration-700" />
                    <div className="absolute top-6 left-6 flex flex-col gap-2">
                      <span className="bg-zinc-950 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest border border-zinc-800">{m.brand}</span>
                    </div>
                    <div className={`absolute bottom-6 right-6 ${m.type === 'Color' ? 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.4)]' : 'bg-zinc-800'} text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest`}>
                      {m.type}
                    </div>
                  </div>
                  <div className="p-8 flex-1 flex flex-col">
                    <h4 className="text-lg font-black text-white mb-2 uppercase tracking-tighter leading-tight group-hover:text-red-500 transition-colors">{m.name}</h4>
                    <p className="text-zinc-500 text-[11px] mb-8 leading-relaxed font-medium line-clamp-2">{m.description}</p>
                    <div className="mt-auto flex items-center justify-between border-t border-zinc-800 pt-8">
                       <div className="flex flex-col">
                          <span className="text-[9px] font-black text-red-500 uppercase tracking-widest">Authorized Unit</span>
                          <span className="text-white font-bold text-xs uppercase">Request Quote</span>
                       </div>
                       <button 
                        onClick={() => { setSelectedMachine(m); setIsModalOpen(true); }}
                        className="w-12 h-12 bg-zinc-950 border border-zinc-800 hover:border-red-600 hover:text-red-500 transition-all rounded-2xl flex items-center justify-center text-zinc-400"
                       >
                         <ArrowRight size={20} />
                       </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Rentals Section */}
      <section id="rentals" className="py-24 bg-zinc-900/20">
        <div className="container mx-auto px-6">
          <SectionHeading title="Office Automation" subtitle="Rental Plans" centered />
          <div className="grid lg:grid-cols-2 gap-10 max-w-5xl mx-auto">
             {[
               { icon: <Building2 />, title: "Standard Office", perks: ["Ideal for SMEs", "Xerox/Canon Support", "Consumables Included"] },
               { icon: <ShieldCheck />, title: "Premium Enterprise", perks: ["Industrial Production Ready", "Zero Downtime Guarantee", "Priority Support"], highlight: true }
             ].map((plan, i) => (
               <motion.div 
                key={i}
                // Fixed invalid property 'p' to 'y' for hover animation
                whileHover={{ y: -10 }}
                className={`p-12 rounded-[3rem] border ${plan.highlight ? 'bg-red-600 border-red-500 shadow-2xl shadow-red-950/30' : 'bg-zinc-900 border-zinc-800'}`}
               >
                 <div className="flex items-center gap-4 mb-8">
                    <div className={`p-4 rounded-2xl ${plan.highlight ? 'bg-white text-red-600' : 'bg-red-600/10 text-red-500'}`}>
                      {plan.icon}
                    </div>
                    <h4 className="text-3xl font-black uppercase tracking-tighter">{plan.title}</h4>
                 </div>
                 <div className="space-y-4 mb-10 text-left">
                   {plan.perks.map((perk, j) => (
                      <div key={j} className="flex items-center gap-3">
                        <CheckCircle2 size={18} className={plan.highlight ? 'text-red-200' : 'text-red-500'} />
                        <span className={`font-bold ${plan.highlight ? 'text-white' : 'text-zinc-400'}`}>{perk}</span>
                      </div>
                   ))}
                 </div>
                 <a href="#contact" onClick={smoothScroll('#contact')} className={`block text-center py-5 rounded-2xl font-black uppercase tracking-widest no-underline transition-all ${plan.highlight ? 'bg-white text-red-600 hover:bg-zinc-100 shadow-xl' : 'bg-zinc-950 text-white hover:bg-zinc-800 border border-zinc-800'}`}>
                    Inquire Now
                 </a>
               </motion.div>
             ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-zinc-950">
        <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <SectionHeading title="Visit Our Store" subtitle="Contact Information" />
            <p className="text-zinc-400 mb-16 text-xl leading-relaxed max-w-lg">
              We handle major brands: <span className="text-white">Xerox, Canon, HP, & Kyocera</span>. Sales, services, and high-quality rentals.
            </p>
            <div className="space-y-10">
              {[
                { icon: <Phone />, label: "Call Us Now", value: "+91 91217 16529", color: "text-red-500" },
                { icon: <Mail />, label: "Mail At", value: "info@innovativetechnologies.in", color: "text-zinc-400" },
                { icon: <MapPin />, label: "Store Address", value: "Shop No. 27, Minerva Complex, Sarojini Devi Rd, Kalasiguda, Secunderabad, Telangana 500003", color: "text-zinc-400" }
              ].map((c, i) => (
                <div key={i} className="flex gap-8 group">
                  <div className="w-16 h-16 bg-zinc-900 rounded-3xl flex items-center justify-center text-red-500 border border-zinc-800 group-hover:bg-red-600 group-hover:text-white transition-all shrink-0 shadow-lg">
                    {c.icon}
                  </div>
                  <div>
                    <h5 className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-2">{c.label}</h5>
                    <p className="text-white font-bold text-lg leading-tight group-hover:text-red-500 transition-colors">{c.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-2 bg-red-600 blur-3xl opacity-[0.05] rounded-[4rem]"></div>
            <div className="relative bg-zinc-900 p-12 md:p-16 rounded-[4rem] border border-zinc-800 shadow-2xl">
              <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Full Name</label>
                    <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:border-red-600 outline-none transition-all placeholder:text-zinc-800" placeholder="Name" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Phone</label>
                    <input type="text" className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:border-red-600 outline-none transition-all placeholder:text-zinc-800" placeholder="+91..." />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Preferred Brand</label>
                  <select className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:border-red-600 outline-none transition-all appearance-none cursor-pointer">
                    <option>XEROX</option>
                    <option>CANON</option>
                    <option>HP</option>
                    <option>KYOCERA</option>
                  </select>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Message</label>
                  <textarea rows={4} className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:border-red-600 outline-none transition-all placeholder:text-zinc-800" placeholder="Requirements..."></textarea>
                </div>
                <button className="w-full bg-red-600 hover:bg-red-700 text-white font-black py-5 rounded-[1.5rem] transition-all flex items-center justify-center gap-3 uppercase tracking-[0.2em] shadow-xl shadow-red-950/40 active:scale-95">
                  Send Proposal
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-950 border-t border-zinc-900 pt-24 pb-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12 mb-20">
             <Logo />
             <div className="flex gap-12 text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 font-bold">
               <span className="text-zinc-400">Superior MARKGOLD Toners Available</span>
             </div>
          </div>
          <div className="pt-12 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-6 text-[10px] font-bold text-zinc-600 uppercase tracking-widest">
            <p>© 2024 Innovative Technologies | Secunderabad</p>
            <div className="flex gap-10">
               <span>Sales</span>
               <span>Services</span>
               <span>Rentals</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Detail Modal */}
      <AnimatePresence>
        {isModalOpen && selectedMachine && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-zinc-950/98 backdrop-blur-xl"
            ></motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="relative bg-zinc-900 border border-zinc-800 rounded-[4rem] max-w-5xl w-full overflow-hidden flex flex-col md:row shadow-3xl"
            >
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute top-8 right-8 z-30 w-12 h-12 bg-zinc-950 text-white rounded-2xl flex items-center justify-center hover:bg-red-600 transition-colors border border-zinc-800"
              >
                <X size={24} />
              </button>
              
              <div className="w-full md:w-1/2 h-[400px] md:h-auto bg-white p-12 flex items-center justify-center">
                <img src={selectedMachine.image} className="max-w-full max-h-full object-contain" alt={selectedMachine.name} />
              </div>
              
              <div className="w-full md:w-1/2 p-16 flex flex-col justify-center bg-zinc-900">
                <div className="flex items-center gap-3 mb-6">
                  <span className="text-red-500 font-black text-[10px] uppercase tracking-[0.4em]">{selectedMachine.brand}</span>
                  <div className="h-[1px] w-6 bg-zinc-700"></div>
                  <span className="text-zinc-500 font-black text-[10px] uppercase tracking-[0.4em]">{selectedMachine.type}</span>
                </div>
                <h3 className="text-5xl font-black text-white mb-8 uppercase tracking-tighter leading-none">{selectedMachine.name}</h3>
                <p className="text-zinc-400 text-lg mb-12 leading-relaxed font-medium">{selectedMachine.description}</p>
                
                <div className="space-y-6 mb-12">
                   {selectedMachine.features.map((f, i) => (
                      <div key={i} className="flex items-center gap-4 text-sm font-bold text-zinc-300">
                         <div className="p-1 rounded-full bg-red-600/10 text-red-500">
                            <CheckCircle2 size={16} />
                         </div>
                         {f}
                      </div>
                   ))}
                </div>

                <div className="flex flex-col sm:flex-row gap-5">
                  <button className="flex-1 bg-red-600 hover:bg-red-700 text-white font-black py-6 rounded-[2rem] transition-all uppercase tracking-widest text-xs">
                    Get Proposal
                  </button>
                  <button 
                    onClick={() => { setIsModalOpen(false); document.querySelector('#rentals')?.scrollIntoView({ behavior: 'smooth' }); }}
                    className="flex-1 border border-zinc-700 hover:bg-zinc-800 text-white font-black py-6 rounded-[2rem] transition-all uppercase tracking-widest text-xs"
                  >
                    Rental Info
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
