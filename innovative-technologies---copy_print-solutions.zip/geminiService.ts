
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMachineRecommendation = async (userNeeds: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `User needs: ${userNeeds}. Suggest whether they should BUY or RENT and which machine type (Xerox, Inkjet, Laser, Production) fits best. Keep it short.`,
      config: {
        systemInstruction: "You are an expert sales assistant for Innovative Technologies, a premium print/copy shop. You offer buying and rental advice.",
        temperature: 0.7,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I recommend speaking with our sales team directly for a personalized quote. Renting is great for short-term needs, while buying is better for long-term ownership.";
  }
};
